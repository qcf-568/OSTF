_base_ = [
    '../_base_/models/cascade_rcnn_convnext_fpn_2fc.py',
    '../_base_/datasets/tamper.py',
    '../_base_/schedules/schedule_1x.py', '../_base_/default_runtime.py'
]
